# Keep Room generated code
-keep class androidx.room.** { *; }
# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
