package com.acr.recorder.data

import android.content.Context

/** Tiny settings store: server upload URL + master on/off switch. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("acr_prefs", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = sp.getString(KEY_URL, "") ?: ""
        set(value) = sp.edit().putString(KEY_URL, value).apply()

    var recordingEnabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, true)
        set(value) = sp.edit().putBoolean(KEY_ENABLED, value).apply()

    companion object {
        private const val KEY_URL = "server_url"
        private const val KEY_ENABLED = "recording_enabled"
    }
}
