package com.acr.recorder.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.CallLog
import android.util.Log
import androidx.core.app.NotificationCompat
import com.acr.recorder.R
import com.acr.recorder.data.AppDatabase
import com.acr.recorder.data.CallRecord
import com.acr.recorder.recorder.CallAudioRecorder
import com.acr.recorder.upload.UploadWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CallRecordingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var recorder: CallAudioRecorder

    private var startTime = 0L
    private var number = ""
    private var incoming = false
    private var recording = false

    override fun onCreate() {
        super.onCreate()
        recorder = CallAudioRecorder(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        if (recording) return
        incoming = intent.getBooleanExtra(EXTRA_INCOMING, false)
        number = intent.getStringExtra(EXTRA_NUMBER).orEmpty()
        val direction = if (incoming) "INCOMING" else "OUTGOING"

        startForegroundCompat(direction, number)

        startTime = System.currentTimeMillis()
        val file = recorder.start(number, direction)
        recording = file != null
        if (!recording) {
            Log.w(TAG, "Recorder did not start; stopping service")
            stopSelf()
        }
    }

    private fun handleStop() {
        if (!recording) { stopSelf(); return }
        recording = false
        val ok = recorder.stop()
        val file = recorder.currentFile
        val endTime = System.currentTimeMillis()
        val duration = (endTime - startTime) / 1000

        if (!ok || file == null || !file.exists() || file.length() == 0L) {
            stopSelf()
            return
        }

        val direction = if (incoming) "INCOMING" else "OUTGOING"
        scope.launch {
            // If we never got a number (common for outgoing on Android 9+),
            // resolve it from the system call log.
            val resolvedNumber = number.ifBlank { resolveNumberFromCallLog() }

            val dao = AppDatabase.get(applicationContext).callRecordDao()
            val id = dao.insert(
                CallRecord(
                    number = resolvedNumber.ifBlank { "Unknown" },
                    direction = direction,
                    startTime = startTime,
                    endTime = endTime,
                    durationSec = duration,
                    filePath = file.absolutePath
                )
            )
            UploadWorker.enqueue(applicationContext, id)
            stopSelf()
        }
    }

    /** Reads the most recent entry from the system call log to fill the number. */
    private fun resolveNumberFromCallLog(): String {
        if (checkSelfPermission(android.Manifest.permission.READ_CALL_LOG)
            != PackageManager.PERMISSION_GRANTED
        ) return ""
        return try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER),
                null, null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "" else ""
            } ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "call log query failed", e); ""
        }
    }

    private fun startForegroundCompat(direction: String, number: String) {
        val text = "$direction ${number.ifBlank { "" }}".trim()
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Recording call")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Call Recording", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.acr.recorder.START"
        const val ACTION_STOP = "com.acr.recorder.STOP"
        const val EXTRA_INCOMING = "incoming"
        const val EXTRA_NUMBER = "number"
        private const val CHANNEL_ID = "call_recording"
        private const val NOTIF_ID = 42
        private const val TAG = "CallRecordingService"
    }
}
