package com.acr.recorder.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CallRecordDao {

    @Insert
    suspend fun insert(record: CallRecord): Long

    @Update
    suspend fun update(record: CallRecord)

    @Query("SELECT * FROM call_records ORDER BY startTime DESC")
    fun observeAll(): Flow<List<CallRecord>>

    @Query("SELECT * FROM call_records WHERE uploaded = 0")
    suspend fun pendingUploads(): List<CallRecord>

    @Query("SELECT * FROM call_records WHERE id = :id")
    suspend fun byId(id: Long): CallRecord?
}
