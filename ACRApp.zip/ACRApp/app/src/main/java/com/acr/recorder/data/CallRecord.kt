package com.acr.recorder.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per recorded call. Holds the metadata + the local file path + upload state.
 */
@Entity(tableName = "call_records")
data class CallRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    /** "INCOMING" or "OUTGOING" */
    val direction: String,
    val startTime: Long,
    val endTime: Long,
    val durationSec: Long,
    val filePath: String,
    val uploaded: Boolean = false,
    val remoteUrl: String? = null
)
