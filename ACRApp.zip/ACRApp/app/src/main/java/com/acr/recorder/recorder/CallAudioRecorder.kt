package com.acr.recorder.recorder

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wraps MediaRecorder.
 *
 * NOTE ON ANDROID LIMITS: Since Android 10 (API 29) the system blocks third-party
 * apps from capturing the *remote* party's audio via VOICE_CALL/VOICE_DOWNLINK.
 * MIC is the source that reliably works: it captures your voice, and captures
 * BOTH sides when the call is on speakerphone. VOICE_COMMUNICATION is tried first
 * because some OEMs route more of the call through it; we fall back to MIC.
 */
class CallAudioRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    var currentFile: File? = null
        private set

    fun start(number: String, direction: String): File? {
        val dir = File(context.getExternalFilesDir(null), "recordings").apply { mkdirs() }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeNumber = number.ifBlank { "unknown" }.replace(Regex("[^0-9+]"), "")
        val file = File(dir, "${direction}_${safeNumber}_$ts.m4a")

        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()

        return try {
            rec.apply {
                // Try the call-oriented source first; many devices give better
                // results, but it is allowed to fall back to MIC.
                try {
                    setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                } catch (e: Exception) {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                }
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44_100)
                setAudioEncodingBitRate(96_000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            recorder = rec
            currentFile = file
            Log.i(TAG, "Recording started -> ${file.absolutePath}")
            file
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording", e)
            runCatching { rec.reset(); rec.release() }
            file.delete()
            currentFile = null
            null
        }
    }

    /** @return true if a valid (non-empty) file was produced. */
    fun stop(): Boolean {
        val rec = recorder ?: return false
        return try {
            rec.stop()
            true
        } catch (e: Exception) {
            // stop() throws if it was stopped almost immediately with no data.
            Log.w(TAG, "stop() failed (call probably too short)", e)
            currentFile?.delete()
            false
        } finally {
            runCatching { rec.reset(); rec.release() }
            recorder = null
        }
    }

    companion object { private const val TAG = "CallAudioRecorder" }
}
