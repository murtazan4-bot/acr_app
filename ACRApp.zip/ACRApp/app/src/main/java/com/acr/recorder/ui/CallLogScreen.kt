package com.acr.recorder.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.acr.recorder.data.CallRecord
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallLogScreen(
    records: Flow<List<CallRecord>>,
    initialUrl: String,
    initialEnabled: Boolean,
    onUrlChange: (String) -> Unit,
    onEnabledChange: (Boolean) -> Unit
) {
    val list by records.collectAsState(initial = emptyList())
    var url by remember { mutableStateOf(initialUrl) }
    var enabled by remember { mutableStateOf(initialEnabled) }

    Scaffold(topBar = { TopAppBar(title = { Text("Call Recorder") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recording enabled", style = MaterialTheme.typography.bodyLarge)
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it; onEnabledChange(it)
                })
            }

            OutlinedTextField(
                value = url,
                onValueChange = { url = it; onUrlChange(it) },
                label = { Text("Upload server URL (https://…/upload)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )

            Divider(Modifier.padding(vertical = 8.dp))
            Text("Recordings (${list.size})", style = MaterialTheme.typography.titleMedium)

            LazyColumn(Modifier.fillMaxSize()) {
                items(list) { r -> RecordRow(r) }
            }
        }
    }
}

@Composable
private fun RecordRow(r: CallRecord) {
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spaceBetween
        ) {
            Icon(
                if (r.direction == "INCOMING") Icons.Default.CallReceived
                else Icons.Default.CallMade,
                contentDescription = r.direction
            )
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(r.number, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${fmt.format(Date(r.startTime))} · ${r.durationSec}s",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Icon(
                if (r.uploaded) Icons.Default.CloudDone else Icons.Default.CloudUpload,
                contentDescription = if (r.uploaded) "Uploaded" else "Pending"
            )
        }
    }
}
