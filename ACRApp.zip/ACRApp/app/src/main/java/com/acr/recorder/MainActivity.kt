package com.acr.recorder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.core.content.ContextCompat
import com.acr.recorder.data.AppDatabase
import com.acr.recorder.data.Prefs
import com.acr.recorder.ui.CallLogScreen

class MainActivity : ComponentActivity() {

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()

        val prefs = Prefs(this)
        val dao = AppDatabase.get(this).callRecordDao()

        setContent {
            MaterialTheme {
                CallLogScreen(
                    records = dao.observeAll(),
                    initialUrl = prefs.serverUrl,
                    initialEnabled = prefs.recordingEnabled,
                    onUrlChange = { prefs.serverUrl = it.trim() },
                    onEnabledChange = { prefs.recordingEnabled = it }
                )
            }
        }
    }

    private fun requestNeededPermissions() {
        val needed = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_PHONE_STATE)
            add(Manifest.permission.READ_CALL_LOG)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }
}
