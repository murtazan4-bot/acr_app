package com.acr.recorder.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.acr.recorder.data.Prefs
import com.acr.recorder.service.CallRecordingService

/**
 * Listens for android.intent.action.PHONE_STATE and starts/stops the recording
 * service accordingly.
 */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!Prefs(context).recordingEnabled) return

        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        // EXTRA_INCOMING_NUMBER is only delivered for incoming calls and only if
        // READ_CALL_LOG is granted on Android 9+. Outgoing numbers are resolved
        // later from the call log inside the service.
        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        val newState = when (stateStr) {
            TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
            TelephonyManager.EXTRA_STATE_IDLE -> TelephonyManager.CALL_STATE_IDLE
            else -> return
        }

        when (val event = CallStateTracker.onState(newState, number)) {
            is CallStateTracker.Event.Started -> {
                val svc = Intent(context, CallRecordingService::class.java).apply {
                    action = CallRecordingService.ACTION_START
                    putExtra(CallRecordingService.EXTRA_INCOMING, event.incoming)
                    putExtra(CallRecordingService.EXTRA_NUMBER, CallStateTracker.incomingNumber)
                }
                ContextCompat.startForegroundService(context, svc)
            }
            is CallStateTracker.Event.Ended -> {
                val svc = Intent(context, CallRecordingService::class.java).apply {
                    action = CallRecordingService.ACTION_STOP
                }
                ContextCompat.startForegroundService(context, svc)
            }
            else -> { /* no-op */ }
        }
    }
}
