package com.acr.recorder.upload

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.acr.recorder.data.AppDatabase
import com.acr.recorder.data.Prefs
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Uploads one recording (by row id) to the configured server as multipart/form-data.
 * Retries automatically with backoff if the network or server is unavailable.
 *
 * Form fields sent:
 *   file        -> the .m4a audio
 *   number, direction, startTime, durationSec, recordId  -> metadata
 */
class UploadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.MINUTES)
        .build()

    override suspend fun doWork(): Result {
        val id = inputData.getLong(KEY_ID, -1L)
        if (id < 0) return Result.failure()

        val url = Prefs(applicationContext).serverUrl
        if (url.isBlank()) {
            Log.w(TAG, "No server URL configured; skipping upload.")
            return Result.success() // nothing to do, not an error
        }

        val dao = AppDatabase.get(applicationContext).callRecordDao()
        val record = dao.byId(id) ?: return Result.failure()
        if (record.uploaded) return Result.success()

        val file = File(record.filePath)
        if (!file.exists()) return Result.failure()

        return try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "file", file.name,
                    file.asRequestBody("audio/mp4".toMediaTypeOrNull())
                )
                .addFormDataPart("number", record.number)
                .addFormDataPart("direction", record.direction)
                .addFormDataPart("startTime", record.startTime.toString())
                .addFormDataPart("durationSec", record.durationSec.toString())
                .addFormDataPart("recordId", record.id.toString())
                .build()

            val request = Request.Builder().url(url).post(body).build()

            client.newCall(request).execute().use { resp ->
                if (resp.isSuccessful) {
                    dao.update(record.copy(uploaded = true, remoteUrl = resp.body?.string()))
                    Result.success()
                } else {
                    Log.w(TAG, "Server returned ${resp.code}; will retry")
                    Result.retry()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Upload failed; will retry", e)
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "UploadWorker"
        private const val KEY_ID = "record_id"

        fun enqueue(context: Context, recordId: Long) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<UploadWorker>()
                .setInputData(workDataOf(KEY_ID to recordId))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                "upload_$recordId", ExistingWorkPolicy.KEEP, request
            )
        }
    }
}
