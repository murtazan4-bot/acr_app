package com.acr.recorder

import android.app.Application

class App : Application()
