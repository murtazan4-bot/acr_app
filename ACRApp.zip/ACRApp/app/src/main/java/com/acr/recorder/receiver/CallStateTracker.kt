package com.acr.recorder.receiver

import android.telephony.TelephonyManager

/**
 * The PHONE_STATE broadcast only gives RINGING / OFFHOOK / IDLE. We need to
 * remember the previous state to decide whether a call was incoming or outgoing:
 *
 *   IDLE -> RINGING -> OFFHOOK  = incoming call answered
 *   IDLE -> OFFHOOK             = outgoing call
 *   * -> IDLE                   = call ended
 */
object CallStateTracker {
    private var lastState = TelephonyManager.CALL_STATE_IDLE
    var isIncoming = false
        private set
    var incomingNumber: String = ""

    sealed class Event {
        data class Started(val incoming: Boolean) : Event()
        object Ended : Event()
        object None : Event()
    }

    fun onState(newState: Int, number: String?): Event {
        if (newState == lastState) return Event.None
        val event = when (newState) {
            TelephonyManager.CALL_STATE_RINGING -> {
                isIncoming = true
                if (!number.isNullOrBlank()) incomingNumber = number
                Event.None // wait until answered (OFFHOOK) to start recording
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (lastState == TelephonyManager.CALL_STATE_IDLE) {
                    isIncoming = false // dialed out
                }
                Event.Started(isIncoming)
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                val ended = lastState != TelephonyManager.CALL_STATE_IDLE
                isIncoming = false
                incomingNumber = ""
                if (ended) Event.Ended else Event.None
            }
            else -> Event.None
        }
        lastState = newState
        return event
    }
}
