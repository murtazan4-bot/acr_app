// Minimal upload server for the Call Recorder app.
// Receives multipart/form-data: file + metadata fields, saves to ./uploads,
// and appends a row to ./uploads/calls.json
//
// Run:
//   npm install
//   node server.js
// Then set the app's "Upload server URL" to:
//   http://YOUR_PC_LAN_IP:3000/upload
// (use your machine's local network IP, not localhost, so the phone can reach it)

const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const UPLOAD_DIR = path.join(__dirname, "uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, Date.now() + "_" + file.originalname),
});
const upload = multer({ storage });

const app = express();

app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).send("no file");

  const meta = {
    storedFile: req.file.filename,
    sizeBytes: req.file.size,
    number: req.body.number,
    direction: req.body.direction,
    startTime: Number(req.body.startTime),
    durationSec: Number(req.body.durationSec),
    recordId: req.body.recordId,
    receivedAt: Date.now(),
  };

  const logPath = path.join(UPLOAD_DIR, "calls.json");
  const log = fs.existsSync(logPath)
    ? JSON.parse(fs.readFileSync(logPath, "utf8"))
    : [];
  log.push(meta);
  fs.writeFileSync(logPath, JSON.stringify(log, null, 2));

  console.log("Received:", meta);
  // The body returned here is stored by the app as remoteUrl.
  res.status(200).send("/files/" + req.file.filename);
});

app.use("/files", express.static(UPLOAD_DIR));

app.listen(3000, () => console.log("Upload server on http://0.0.0.0:3000"));
